export default {
  accessTokenPublicKey: "accessTokenPublicKey",
  accessTokenPrivateKey: "accessTokenPrivateKey",
  refreshTokenPublicKey: " refreshTokenPublicKey",
  refreshTokenPrivateKey: "refreshTokenPrivateKey",
};
