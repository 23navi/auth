export default {
  port: 3005,
  dbUri: "mongodb://localhost:27017/auth-test",
  logLevel: "info",
  smtp: {
    user: "armando.wuckert@ethereal.email",
    pass: "hYYGu6ag3sQD4XszX3",
    host: "smtp.ethereal.email",
    port: 587,
    secure: false,
  },
  // All of it is base64 encoded
  accessTokenPublicKey: "",
  accessTokenPrivateKey: "",
  refreshTokenPublicKey: "",
  refreshTokenPrivateKey: "",
};
